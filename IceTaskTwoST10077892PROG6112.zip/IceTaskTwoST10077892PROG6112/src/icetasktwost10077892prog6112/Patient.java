package icetasktwost10077892prog6112;

class Patient {
    String name;
    int age;
    String gender;

    public Patient(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
}

class Female extends Patient {
    public Female(String name, int age) {
        super(name, age, "Female");
    }

    public String checkEligibility() {
        if (age < 18) {
            return "Not eligible for treatment at the emergency room. Referred to Durban (DBN) Hospital.";
        } else {
            return "Eligible for treatment.";
        }
    }
}

class Male extends Patient {
    private boolean hasChronicDisorder;

    public Male(String name, int age, boolean hasChronicDisorder) {
        super(name, age, "Male");
        this.hasChronicDisorder = hasChronicDisorder;
    }

    public String checkEligibility() {
        if (age >= 18) {
            if (hasChronicDisorder) {
                return "Not eligible for treatment at the emergency room. Transferred to Johannesburg (JHB) Hospital.";
            } else {
                return "Eligible for treatment at Durban (DBN) Hospital.";
            }
        } else {
            return "Not eligible for treatment.";
        }
    }
}

