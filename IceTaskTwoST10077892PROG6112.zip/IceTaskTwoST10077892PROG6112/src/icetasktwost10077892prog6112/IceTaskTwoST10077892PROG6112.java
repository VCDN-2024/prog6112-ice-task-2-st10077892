package icetasktwost10077892prog6112;

import java.util.ArrayList;
import java.util.Scanner;

public class IceTaskTwoST10077892PROG6112 {
    private static ArrayList<Patient> patients = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        
        
        patients.add(new Female("Alice", 17));
        patients.add(new Male("Bob", 20, true));
        patients.add(new Male("Charlie", 15, false));
        patients.add(new Female("Diana", 25));

        
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();

        if (login.authenticate(username, password)) {
            System.out.println("Login Successful!");

            
            System.out.print("Enter patient name to search: ");
            String searchName = scanner.nextLine();
            boolean found = false;
            
            for (Patient patient : patients) {
                if (patient.name.equalsIgnoreCase(searchName)) {
                    System.out.println("Patient found: " + patient.name);
                    found = true;
                    break;
                }
            }
            if (!found) {
                System.out.println("Patient not found!");
            }

            
            System.out.println("\nAll Patients:");
            for (Patient patient : patients) {
                String eligibility = "";
                if (patient instanceof Female) {
                    eligibility = ((Female) patient).checkEligibility();
                } else if (patient instanceof Male) {
                    eligibility = ((Male) patient).checkEligibility();
                }
                System.out.println(patient.name + " (" + patient.gender + ", " + patient.age + " years): " + eligibility);
            }
        } else {
            System.out.println("Login Failed. Incorrect Username or Password.");
        }
    }
}

