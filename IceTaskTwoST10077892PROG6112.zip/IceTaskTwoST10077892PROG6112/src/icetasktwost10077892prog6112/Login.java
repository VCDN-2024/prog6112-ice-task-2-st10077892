package icetasktwost10077892prog6112;

import java.util.ArrayList;
import java.util.Scanner;

class Login {
    private static final String USERNAME = "Admin";
    private static final String PASSWORD = "St@a77";

    public boolean authenticate(String username, String password) {
        return USERNAME.equals(username) && PASSWORD.equals(password);
    }
}


